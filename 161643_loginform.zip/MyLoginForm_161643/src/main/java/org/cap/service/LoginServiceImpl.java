package org.cap.service;

import org.cap.dao.ILoginDao;
import org.cap.dao.LoginDaoImpl;
import org.cap.model.LoginBean;

public class LoginServiceImpl implements ILoginService{
	
	ILoginDao dao=new LoginDaoImpl();

	@Override
	public boolean isValid(LoginBean loginbean) {
		
		if(dao.isValid(loginbean))
	
		return true;
		else {
			return false;
		}
	
	}

}
