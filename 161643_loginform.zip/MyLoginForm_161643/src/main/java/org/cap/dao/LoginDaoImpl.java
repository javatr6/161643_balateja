package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.cap.model.LoginBean;



public class LoginDaoImpl  implements ILoginDao{
	
	
	
	
	

	@Override
	public boolean isValid(LoginBean loginbean) {
		String sql= "select * from Logintable where UserName=? and UserPassword=?";
		try(
		PreparedStatement pst= getSqlConnection().prepareStatement(sql);
				){
			
			pst.setString(1, "UserName");
			pst.setString(2, "Userpassword");
			ResultSet rs= pst.executeQuery();
			if(rs.next())
			{
				
			}
			
			
		return false;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return false;

}




	private Connection getSqlConnection() throws SQLException {
	Connection connection = null;
	try {
		
		Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","India123");
		
		
	}catch(ClassNotFoundException e)
	
	{		
	e.printStackTrace();
	}
	return connection;
	}
}