package org.cap.model;

public class LoginBean {
	private String UserName;
	private String UserPassword;
	
	public LoginBean() {
		super();
	}

	public LoginBean(String userName, String userPassword) {
		super();
		UserName = userName;
		UserPassword = userPassword;
	}
	
	

}
