package org.cap.demo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServelet3
 */
@WebServlet("/MyServelet3")
public class MyServelet3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	
			response.getWriter().append("Served at: ").append(request.getContextPath());
					response.setContentType("text/html");
					System.out.println("MyhttpServlet Service");
					PrintWriter out=response.getWriter();
					out.println("<h1 style='color:blue'> Hello.. Welcome to servlets </h1>"); 
			 

		
	}

}
