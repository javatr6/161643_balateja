package com.capgemini;

import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.Style;

@WebService
@SOAPBinding(style=Style.DOCUMENT)
public interface CalculateSI {
	public int calcSI(int num1, int num2,int num3);
	

}
