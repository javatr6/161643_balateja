package com.capgemini;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;



public class Tester {

	public static void main(String[] args) throws MalformedURLException {

		URL url = new URL("http://localhost:7703/ws/CalculateSI?wsdl");
		QName qname =new QName("http://capgemini.com/","CalculateSIImplService");
		
		Service service = Service.create(url,qname);
		CalculateSI calculatE = service.getPort(CalculateSI.class);
		System.out.println(calculatE.calcSI(1000,2,5));

	}

}
