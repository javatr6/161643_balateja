/**
 * 
 */
function employee(empId,empName,salary){
	var emp={};
	emp.empId=empId;
	emp.empName=empName;
	emp.salary=salary;
	return emp;
}

var empobj=employee(1001,'John',34000)
console.log('EmployeeId'+empobj.empId);
console.log('EmployeeName'+empobj.empName);
console.log('EmployeeSalary'+empobj.salary);