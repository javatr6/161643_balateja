/**
 * 
 */
var emp=new Object({
	empId:1001,
	empName:'John',
	salary:2000,
	greet:function(){
		alert("welcome")
	}
	
})
console.log(emp.greet)