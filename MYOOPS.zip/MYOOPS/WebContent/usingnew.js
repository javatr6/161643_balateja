/**
 * 
 */
function employee(empId,empFirstName,empLastName,salary){
	
	this.empId=empId;
	this.empFirstName=empFirstName;
	this.salary=salary;
	this.empLastName=empLastName;
	this.getName=function(){
		return this.empName=this.empFirstName+' '+this.empLastName ;
	}

}

var empobj=new employee(1001,'John',34000)
console.log('EmployeeId'+empobj.empId);
console.log('EmployeeFirstName'+empobj.empFirstName);
console.log('EmployeeLastName'+empobj.empLastName);
console.log('EmployeeSalary'+empobj.salary);
console.log('EmployeeFullName'+empobj.getName())
