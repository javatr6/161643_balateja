package beans;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BookingPageBean {
	
	@FindBy(name="txtFN")
	private WebElement firstName;
	
	@FindBy(name="txtLN")
	private WebElement lastName;
	
	@FindBy(id="txtEmail")
	private WebElement email;
	
	@FindBy(id="txtPhone")
		private WebElement phone;
	@FindBy(xpath="/html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")
			private WebElement address;
	@FindBy(name="city")
			private WebElement city;
	@FindBy(name="state")
			private WebElement state;
	@FindBy(name="persons")
			private WebElement numberOfGuestsstaying;
	@FindBy(id="txtCardholderName")

			private WebElement cardHolderName;
	@FindBy(id="txtDebit")
			private WebElement debitCardNumber;
	@FindBy(id="txtCvv")
			private WebElement cvv;
	@FindBy(id="txtMonth")
			private WebElement expireMonth;
	@FindBy(id="txtYear")
			private WebElement expireYear;
	@FindBy(id="btnPayment")
			private WebElement confirmBtn; 
		 

	
	private WebDriver driver;
	
	public String getPhone() {
		return phone.getText();
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public String getAddress() {
		return address.getText();
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public String getCity() {
		return city.getText();
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public String getState() {
		return state.getText();
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public String getNumberOfGuestsstaying() {
		return numberOfGuestsstaying.getText();
	}

	public void setNumberOfGuestsstaying(String numberOfGuestsstaying) {
		this.numberOfGuestsstaying  .sendKeys(numberOfGuestsstaying);	}

	public String getCardHolderName() {
		return cardHolderName.getText();
	}

	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName .sendKeys(cardHolderName);
	}

	public String getDebitCardNumber() {
		return debitCardNumber.getText();
	}

	public void setDebitCardNumber(String debitCardNumber) {
		this.debitCardNumber .sendKeys(debitCardNumber);
	}

	public String getCvv() {
		return cvv.getText();
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public String getExpireMonth() {
		return expireMonth.getText();
	}

	public void setExpireMonth(String expireMonth) {
		this.expireMonth.sendKeys(expireMonth);
	}

	public String getExpireYear() {
		return expireYear.getText();
	}

	public void setExpireYear(String expireYear) {
		this.expireYear.sendKeys(expireYear);
	}

	public BookingPageBean(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	public String getFirstName( ) {
		return firstName.getText();
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return lastName.getText();
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return email.getText();
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public void setConfirmBookingBtn() {
		this.confirmBtn.click();
	}
	
	
	public void assignValues(String firstName,String lastName,String email,String phone,String address,String city,
			String state,String numberOfGuestsstaying,String cardHolderName,String debitCardNumber,String cvv,String expireMonth,String expireYear
			
			) {
		setFirstName(firstName);
		setLastName(lastName);
		setEmail(email);
		 setPhone( phone);
		setExpireYear(expireYear);
		setExpireMonth(expireMonth);
		setCvv(cvv);
		setDebitCardNumber(debitCardNumber);
		 setCardHolderName( cardHolderName);
		 setNumberOfGuestsstaying(numberOfGuestsstaying);
		 setState( state);
		 setCity( city) ;
		
		
	}
	

}
