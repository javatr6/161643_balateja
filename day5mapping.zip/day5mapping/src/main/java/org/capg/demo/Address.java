package org.capg.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {
	@Id
	@GeneratedValue
	private int addId;
		private String addr;
		
		
		@OneToOne
		@JoinColumn(name="cusdIdFk")
		private Customer customer;
		
	
	public Address(String addr, Customer customer) {
			super();
			this.addr = addr;
			this.customer = customer;
		}


	public Address(String addr) {
			super();
			this.addr = addr;
		}
	
	
	public Address() {
		
	}
	public int getAddId() {
		return addId;
	}
	public void setAddId(int addId) {
		this.addId = addId;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public Address(int addId, String addr) {
		super();
		this.addId = addId;
		this.addr = addr;
	}
	@Override
	public String toString() {
		return "Address [addId=" + addId + ", addr=" + addr + "]";
	}
	

}
