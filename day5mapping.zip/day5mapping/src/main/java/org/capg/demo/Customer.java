package org.capg.demo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Customer {
	
	@Id
	@GeneratedValue
	private int  custId;
private	String custName;
	private String lastName;
	private double regFees;
	
	

	
	
	public Customer() {
		
	}
	
	public Customer(int custId, String custName, String lastName, double regFees) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.lastName = lastName;
		this.regFees = regFees;
	}

	
	
   public int getCustId() {
		return custId;
	}


	public Customer(String custName, String lastName, double regFees) {
	super();
	this.custName = custName;
	this.lastName = lastName;
	this.regFees = regFees;
}

	public void setCustId(int custId) {
		this.custId = custId;
	}


	public String getCustName() {
		return custName;
	}


	public void setCustName(String custName) {
		this.custName = custName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public double getRegFees() {
		return regFees;
	}


	public void setRegFees(double regFees) {
		this.regFees = regFees;
	}


	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", lastName=" + lastName + ", regFees="
				+ regFees + "]";
	}
	
	

}
