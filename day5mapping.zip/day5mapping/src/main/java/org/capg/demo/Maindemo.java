package org.capg.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Maindemo {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		
		
		transaction.begin();
		
		Customer bala= new Customer("balateja","bommeri",2300.00);
Address address = new Address("hyderabad", bala);



Customer teja= new Customer("bhanuteja","bommeri",2300.00);
Address address1 = new Address("hyderabad", teja);

entityManager.persist(bala);
entityManager.persist(address);

entityManager.persist(teja);
entityManager.persist(address1);

transaction.commit();
entityManager.close();
	}

}
