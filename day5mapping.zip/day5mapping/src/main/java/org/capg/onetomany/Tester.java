package org.capg.onetomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Tester {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction= entityManager.getTransaction();
		
		
		transaction.begin();
		
		Company company = new Company("BOA");
		Company company1 = new Company("HIL");
		
	
				Employee employee1=new Employee("balateja ",company);
				Employee employee2=new Employee("bhanuteja",company1);
				
				
				entityManager.persist(company);
				entityManager.persist(company1);
				
				
			
				entityManager.persist(employee1);
				entityManager.persist(employee2);
				
				
				transaction.commit();
				entityManager.close();
		

	}

}
