package org.capg.onetomany;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {
	
	@Id
	@GeneratedValue
private int empId;
private String empName;

@ManyToOne
@JoinColumn(name="companyIdFk")
private Company company;

public Employee(String empName, Company company) {
	super();
	this.empName = empName;
	this.company = company;
}


public int getEmpId() {
	return empId;
}


public void setEmpId(int empId) {
	this.empId = empId;
}


public String getEmpName() {
	return empName;
}


public void setEmpName(String empName) {
	this.empName = empName;
}


public Company getCompany() {
	return company;
}


public void setCompany(Company company) {
	this.company = company;
}


}
