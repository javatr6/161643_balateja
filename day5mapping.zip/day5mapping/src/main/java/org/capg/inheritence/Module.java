package org.capg.inheritence;

import javax.persistence.Entity;

@Entity
public class Module extends Project {
	private String  moduleName;

	

	public Module() {
		
	}

	public Module(int projectId, String projectName, String moduleName) {
		super(projectId, projectName);
		this.moduleName = moduleName;
	}

	public Module(int projectId, String projectName) {
		super(projectId, projectName);
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	@Override
	public String toString() {
		return "Module [moduleName=" + moduleName + "]";
	}
	

}
