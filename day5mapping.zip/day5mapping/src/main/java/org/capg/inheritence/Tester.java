package org.capg.inheritence;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Tester {

	public static void main(String[] args) {
	
			 {
					EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpademo");
					EntityManager entityManager=emf.createEntityManager();
					EntityTransaction transaction=entityManager.getTransaction();
					
					transaction.begin();
					Project project=new Project(100,"capgemini");
				org.capg.inheritence.Module module=new Module();
					module.setModuleName("jap");
					module.setProjectName("capg");
					module.setProjectId(101);
					Task task=new Task();
					task.setTaskName("Inheritance Task");
					task.setModuleName("day5-jpa");
					task.setProjectName("capgemini project");
					task.setProjectId(102);
					entityManager.persist(project);
					entityManager.persist(module);
					entityManager.persist(task);
					transaction.commit();
					entityManager.close(); 
			 

	}

}}
