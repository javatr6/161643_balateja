package com.capgemini.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.capgemini.model.Product;

public class ProductDaoImpl implements IproductDao{
	
	private static List<Product> products=dummyDB();

	public List<Product> getAllProducts() {
	
		return products;
	}

	private static List<Product> dummyDB() {
		List<Product> products=new ArrayList<Product>();
		products.add(new Product(1, "Samsung J9"));
		products.add(new Product(3451, "Sony Xperia"));
		products.add(new Product(543223, "iPhone x"));
		products.add(new Product(565, "iPhone Xs"));
		products.add(new Product(1001, "Sonay ZL"));
		
		return products;
	}

	public List<Product> deleteProducts(Integer productId) {
		Iterator<Product> iterator=products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId().equals(productId)) {
				iterator.remove();
				break;
			}
		}
		return products;
	}

	public List<Product> addProducts(Integer productId, String productName) {
		products.add(new Product(productId,productName));
		return products;
	}

	public Product findProducts(Integer productId) {

		Iterator<Product> iterator=products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId().equals(productId)) {
			
				return product;
			}
		}
		return null;
	}

	public Product updateProducts(Integer productId, String productName) {
		Iterator<Product> iterator = products.iterator();
		while(iterator.hasNext()) {
			Product product=iterator.next();
			if(product.getProductId().equals(productId)) {
				product.setProductName(productName);
			return product;

			}
		}
		return null;
	}
	
	

	

			

}
